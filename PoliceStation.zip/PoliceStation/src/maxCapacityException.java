
public class maxCapacityException extends Exception {

}
