
public class Officer extends PatrolCop {
	
	//Additional fields of the class 

	private int rank;
	
	//Constructors:

	public Officer(String name, int ID, double experience, int factor, boolean canDrive, int rank) throws wrongIDException, wrongRankException { // constructor
		super(name, ID, experience, factor, canDrive);
		if(this.rank<0) {
			throw new wrongRankException();
		}
		this.rank = rank;
		salary += factor * rank;

	}

	public Officer(Officer Of) { // constructor
		super(Of);
		this.rank = Of.getRank();
	}
	
	//Methods of the class:

	public void salary() { // update officer salary
		salary += factor * rank;
	}
	
	//Getters;
	
	public int getRank() {
		return rank;
	}


}//class
