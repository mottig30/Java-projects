
public interface Experienceable {
public double getExperience();
}
