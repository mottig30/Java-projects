import java.util.ArrayList;

public class Car extends Vehicle {
	
	//Methods of the class:
	
	private int capacity;
	private double fuelCap;
	
	//Constructors:

	public Car(int carId, int speed, double usageCost, int capacity, double fuelCap) 
			throws impossibleCapacityException {// constructor
		super(carId, speed, usageCost);
		this.fuelCap = fuelCap;
		if (capacity < 3 || capacity > 6)
			throw new impossibleCapacityException();
		else {
			this.capacity = capacity;
		}
	}

	public Car(Car c) {// constructor to return the car to available
		super(c);
		this.fuelCap = c.getFuelCap();
		this.capacity = c.getcapacity();
	}
	
	//Methods of the class:
	
	public void addPatrolCop(PatrolCop pC) throws maxCapacityException  {// abstract imp add patrol cop to vehicle if needed
        boolean copadded=false;
		if (vehicleWithCops.size() == capacity) {
			throw new maxCapacityException();
		}
		
		if(vehicleWithCops.size()<capacity&&vehicleWithCops.size()!=capacity-1&&copadded==false) {
					vehicleWithCops.add(pC);
		            copadded=true;
	}
        if(vehicleWithCops.size()<capacity&&vehicleWithCops.size()==capacity-1&&howMuchCopsWithLicense(vehicleWithCops)==0&&pC.canDrive==true
				&&copadded==false) {
					vehicleWithCops.add(pC);
                     copadded=true;
	}
		
        
        if(vehicleWithCops.size()<capacity&&vehicleWithCops.size()==capacity-1&&howMuchCopsWithLicense(vehicleWithCops)!=0
                &&copadded==false) {
					vehicleWithCops.add(pC);
					copadded=true;
        }
        
        if(vehicleWithCops.size()==0&&copadded==false) { 
		         	vehicleWithCops.add(pC);
		         	copadded=true;
        }
	}
	
	public boolean ifUnwantedCopInTheSameCar(PatrolCop pC,ArrayList<PatrolCop> vehiclecops) {
		for (int i=0;i<vehicleWithCops.size();i++) {
			if(vehicleWithCops.get(i).UnwantedCop.contains(pC)==false) //solve the unwanted cop in the same car issue
				return true;
		}		
			return false;
		}
	public boolean checkIfOfficerInCar(ArrayList<PatrolCop> vehiclecops) {// checking if already officer in car

		for (int i = 0; i < vehiclecops.size(); i++) {
			if (vehiclecops.get(i) instanceof Officer)
				return true;
		}
		return false;
	}
	
	public int howMuchCopsWithLicense(ArrayList<PatrolCop> vehiclecops) {// check the number of cops with license in the car

		int howMatchCopsWithLicens = 0;
		for (int i = 0; i < vehiclecops.size(); i++) {
			if (vehiclecops.get(i).canDrive==true)
				howMatchCopsWithLicens = howMatchCopsWithLicens + 1;
		}
		return howMatchCopsWithLicens;
	}
	
	public int returnTheCopWitheLicens(ArrayList<PatrolCop> vehiclecops) {// car with 1 cop with license

		int index = 0;
		for (int i = 0; i < vehiclecops.size(); i++) {
			if (vehiclecops.get(i).canDrive)
				index = i;
		}
		return index;
	}
	
	public void addOfficer(Officer officer) {// add officer to vehicle if needed
		
		boolean officeradded=false;
		
		if (checkIfOfficerInCar(vehicleWithCops) == false && howMuchCopsWithLicense(vehicleWithCops) == 0&&officeradded==false) { // case car full and no officer and more than 1 with license
			vehicleWithCops.remove(0);
			vehicleWithCops.add(officer);
		    officeradded=true;
	}

		if (checkIfOfficerInCar(vehicleWithCops) == false && howMuchCopsWithLicense(vehicleWithCops) >= 1&&officeradded==false) { // case car full and no officer and more than 1 with license
			vehicleWithCops.remove(0);
			vehicleWithCops.add(officer);
		    officeradded=true;
	}
		if (checkIfOfficerInCar(vehicleWithCops) == false && howMuchCopsWithLicense(vehicleWithCops) == 1&&officeradded==false) {// case car with 1 cop with license
			for (int i=0;i<vehicleWithCops.size();i++) {
				if(!vehicleWithCops.get(i).canDrive) {
					vehicleWithCops.remove(i);
					vehicleWithCops.add(officer);
					 officeradded=true;
				break;
			}
		}

	}
	}
	
	//Getters:

	public double getFuelCap() {
		return fuelCap;
	}

	public int getcapacity() {
		return capacity;
	}



}// class
