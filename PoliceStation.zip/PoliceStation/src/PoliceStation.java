import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

//Fields of the class

public class PoliceStation {
	private ArrayList<CrimeEvent> eventList;// list of all of the events that happend
	private ArrayList<PatrolCop> availableCops;// list of the cops that are not in event
	private ArrayList<Vehicle> availableVehicle;// list of the vehicles that are not in event
	private ArrayList<Officer> officerList;
	private Vehicle maxVehicle;// temporary highest car with speed
	private PatrolCop maxPatrolCop;// temporary highest cop with experience

	// constructors

	public PoliceStation(String cops, String copFight, String vehicle)
			throws wrongIDException, impossibleCapacityException, IOException, wrongRankException {// constructor

		this.availableCops = new ArrayList<PatrolCop>();
		this.eventList = new ArrayList<CrimeEvent>();
		this.availableVehicle = new ArrayList<Vehicle>();

		ArrayList<String> copsStringList = turnFileIntoStringList(cops);
		turnStringToCop(copsStringList);
		ArrayList<String> vehicleStringList = turnFileIntoStringList(vehicle);
		turnStringToVehicle(vehicleStringList);
		ArrayList<String> unWantedCopList = turnFileIntoStringList(copFight);
		makeListForEachCop(unWantedCopList);
	}

	// Class methods

	public boolean eventHandling(int level, String location) {

		if (level == 1) {
			return HandlingCops(3, 1, location);
		}

		if (level == 2) {
			return HandlingCops(5, 2, location);
		}
		if (level == 3) {
			return HandlingCops(8, 3, location);
		}
		if (level == 4) {
			return HandlingCops(10, 4, location);
		}
		if (level == 5) {
			return HandlingCops(15, 5, location);
		}

		return false;

	}

	private boolean HandlingCops(int C, int level, String location) {// the main method that put cop into vehicles
		CrimeEvent NewEvent = new CrimeEvent(level, location);
		eventList.add(NewEvent);
		int spaceLeftInThecar = 0;
		int numOfCopsAllReadyPlaced = 0;// for tracking the cops
		int numOfCopsNeedToPlaced = C;
		Vehicle maxVehicle = (Vehicle) getMax(availableVehicle);
		PatrolCop maxPatrolCop = (PatrolCop) getMax(availableCops);
		while (numOfCopsNeedToPlaced != 0) {// placed all the cop that required in the event loop
			spaceLeftInThecar = maxVehicle.getcapacity();// capacity of the car counter
			while (spaceLeftInThecar != 0) {// fill car with cop loop
				if (numOfCopsNeedToPlaced == 0)
					break;
				if (isUnWanted(maxPatrolCop, maxVehicle) == false) {
					try {
						maxVehicle.addPatrolCop(maxPatrolCop);
						NewEvent.allCopsInEvent++;
					} catch (maxCapacityException e) {
						e.printStackTrace();
					}
					availableCops.remove(maxPatrolCop);
					maxPatrolCop = (PatrolCop) getMax(availableCops);// new cop
					numOfCopsNeedToPlaced--;
					numOfCopsAllReadyPlaced++;
					spaceLeftInThecar--;
				}
			} // while #1

			if (maxVehicle instanceof Car) {// case car full with no officer and add officer
				Officer o;
				if (ifVehicleContainOfficer((Car) maxVehicle) == false) {
					for (int i = 0; i < availableCops.size(); i++) {
						if (availableCops.get(i) instanceof Officer) {
							o = (Officer) availableCops.get(i);
							maxVehicle.addOfficer(o);
							availableCops.remove(o);
							break;
						}
					} // for
				}
			}

			// update the vehicle:
			if (numOfCopsNeedToPlaced != 0) {
				NewEvent.addVehicle(maxVehicle);
				availableVehicle.remove(maxVehicle);
				maxVehicle = (Vehicle) getMax(availableVehicle);// new vehicle
			}
			if (numOfCopsNeedToPlaced == 0) {
				NewEvent.addVehicle(maxVehicle);
				availableVehicle.remove(maxVehicle);
			}

		} // while 2
		if (numOfCopsNeedToPlaced == 0)
			return true;
		else
			return false;
	}

	public void closeEvent(String location) {
		boolean realEvent = false;
		int i;
		double vehiclesCost = 0;
		double copsCost = 0;
		double avarageExperienceSum = 0;
		for (i = 0; i < eventList.size() && !realEvent; i++) { // searching for an event
			if (location.equals(eventList.get(i).getLocation()) && eventList.get(i).isEventClose() == false)
				realEvent = true;

			CrimeEvent event = eventList.get(i);
			if (realEvent && event.isValidEvent()) {
				System.out.println("Crime Event Ended:");
				System.out.println("Location: " + location);
				System.out.println("Level: " + eventList.get(i).getLevel());
				System.out.println("Number of cops in the event: " + eventList.get(i).allCopsInEvent);
				for (Vehicle vehicle : event.getVehiclesReadyForEvent()) {
					for (PatrolCop patrolCop : vehicle.getVehicleWithCops()) {
						avarageExperienceSum += patrolCop.getExperience();
					}
				}
				System.out.println(
						"Cops avarage years of experience: " + avarageExperienceSum / eventList.get(i).allCopsInEvent);
				for (Vehicle vehicle : event.getVehiclesReadyForEvent()) {
					vehiclesCost = totalExpenses(event.getVehiclesReadyForEvent());
					for (PatrolCop patrolCop : vehicle.getVehicleWithCops()) {
						copsCost = totalExpenses(vehicle.getVehicleWithCops());
					}
				}
				System.out.println("Event cost: " + (copsCost + vehiclesCost));
				System.out.println("Most expensive vehicle: " + mostExpensiveVehicle(event.getVehiclesReadyForEvent()));
				System.out.println();
				System.out.println();
				returnTheCopsAndVehiclesAvailable(event.getVehiclesReadyForEvent());
				event.setEventClose(true);
			}
		} // for loop
		if (realEvent == false) {
			System.out.println("The location you have entered has no open event");
		}

	}// close event

	public static Comparable getMax(ArrayList<? extends Comparable> List) { // Finds the max each comparable list
																			// according her natural comparable

		Comparable max = List.get(0);
		for (int i = 0; i < List.size(); i++) {
			if (List.get(i).compareTo(max) >= 0) {
				max = List.get(i);
			}
		}
		return max;
	}

	private boolean ifVehicleContainOfficer(Car V) {
		for (int i = 0; i < V.vehicleWithCops.size(); i++) {
			if (V.vehicleWithCops.get(i) instanceof Officer)
				return true;
		}
		return false;
	}

	private boolean isUnWanted(PatrolCop P, Vehicle V) {// unwanted cop in the same vehicle
		for (int i = 0; i < P.UnwantedCop.size(); i++)
			if (V.vehicleWithCops.contains(P.UnwantedCop.get(i))) {
				return true;
			}
		return false;
	}

	private int getMaxVehicleCapacity(Vehicle v) {
		return v.capacity;
	}

	private int mostExpensiveVehicle(ArrayList<Vehicle> vehiclesReadyForEvent) {
		double max = 0;
		int vID = 0;
		for (int i = 0; i < vehiclesReadyForEvent.size(); i++) {
			if (vehiclesReadyForEvent.get(i).getCost() > max) {
				max = vehiclesReadyForEvent.get(i).getCost();
				vID = vehiclesReadyForEvent.get(i).getCarID();
			}
		}
		return vID;
	}

	private void returnTheCopsAndVehiclesAvailable(ArrayList<Vehicle> vehiclesReadyForEvent) {
		for (Vehicle vehicle : vehiclesReadyForEvent) {
			for (PatrolCop patrolCop : vehicle.getVehicleWithCops()) {
				if (patrolCop instanceof Officer) {
					availableCops.add(new PatrolCop((Officer) patrolCop));
				} else {
					availableCops.add(new PatrolCop(patrolCop));
				}
			}
			if (vehicle instanceof Motorcycle) {
				vehicle.vehicleWithCops.clear();
				availableVehicle.add(new Motorcycle((Motorcycle) vehicle));
			}
			if (vehicle instanceof Car) {
				vehicle.vehicleWithCops.clear();
				availableVehicle.add(new Car((Car) vehicle));
			}
		}
	}

	public static double totalExpenses(ArrayList<? extends Costable> ExpensesArray) { // make new array of all costable
																						// thing and calculating the
																						// total expense of an array
		double sumExpenses = 0;
		for (int i = 0; i < ExpensesArray.size(); i++) {
			sumExpenses += (ExpensesArray.get(i)).getCost();
		}
		return (int) sumExpenses;
	}

	public static double averageExperience(ArrayList<? extends Experienceable> experienceArray) { // calculating the
																									// average
																									// experience of an
																									// array
		double sum = 0;
		double average = 0;
		for (int i = 0; i < experienceArray.size(); i++) {
			sum += experienceArray.get(i).getExperience();
		}
		average = sum / experienceArray.size();
		return average;
	}

	// Turning the text files into lists methods

	private void makeListForEachCop(ArrayList<String> unWantedCopList) {
		for (int i = 0; i < unWantedCopList.size() - 1; i++) {
			String[] splitted = unWantedCopList.get(i).split("\t");
			int CopID = Integer.parseInt(splitted[0]);
			int dontLikeCop = Integer.parseInt(splitted[1]);
			PatrolCop p;
			for (int j = 0; j < availableCops.size() - 1; j++) {
				if (availableCops.get(j).ID == dontLikeCop) {
					p = availableCops.get(j);
					boolean copFound = false;
					int k = 0;
					while (!copFound) {
						if (availableCops.get(k).getID() == CopID) {
							availableCops.get(k).UnwantedCop.add(p);
							copFound = true;
						} // if
						else {
							k = k + 1;
						}
					} // while
				} // if
			} // for
		}
	}

	private void turnStringToVehicle(ArrayList<String> vehicleStringList) throws impossibleCapacityException {
		for (int i = 0; i < vehicleStringList.size() - 1; i++) {
			String[] splitted = vehicleStringList.get(i).split("\t");
			int ID = Integer.parseInt(splitted[0]);
			String type = splitted[1];
			int speed = Integer.parseInt(splitted[2]);
			double usageCost = Double.parseDouble(splitted[3]);
			Vehicle v;

			if (splitted.length == 6) {
				int capacity = Integer.parseInt(splitted[4]);
				double fuelCap = Double.parseDouble(splitted[5]);
				v = new Car(ID, speed, usageCost, capacity, fuelCap);
			} else {
				v = new Motorcycle(ID, speed, usageCost);
			}
			this.availableVehicle.add(v);
		}
	}

	private void turnStringToCop(ArrayList<String> copsStringList) throws wrongIDException, wrongRankException {
		for (int i = 0; i < copsStringList.size() - 1; i++) {
			String[] splitted = copsStringList.get(i).split("\t");
			String name = splitted[0];
			int ID = Integer.parseInt(splitted[1]);
			String type = splitted[2];
			double experience = Double.parseDouble(splitted[3]);
			int factor = Integer.parseInt(splitted[4]);
			boolean canDrive = false;
			int canDriveNum = Integer.parseInt(splitted[5]);
			PatrolCop p;

			if (canDriveNum == 1) {
				canDrive = true;
			}
			if (splitted.length == 7) {
				int rank = Integer.parseInt(splitted[6]);
				p = new Officer(name, ID, experience, factor, canDrive, rank);
			} else {
				p = new PatrolCop(name, ID, experience, factor, canDrive);

			}
			this.availableCops.add(p);
		}
	}

	private ArrayList<String> turnFileIntoStringList(String F) throws IOException {

		BufferedReader inFile = null;
		ArrayList<String> ans = new ArrayList<String>();

		try {
			FileReader fr = new FileReader(F);
			inFile = new BufferedReader(fr);

			String lineData = inFile.readLine();

			while (true) {
				lineData = inFile.readLine(); // skip first line
				ans.add(lineData);
				if (lineData == null)
					break;

				handleLine(lineData);
			}
		}

		catch (FileNotFoundException exception) {
			System.err.println("The file " + F + " was not found.");
		} catch (IOException exception) {
			System.err.println(exception);
		} finally {
			inFile.close();
		}
		return ans;
	}

	private void handleLine(String lineData) {

	}

	// Getters

	public ArrayList<PatrolCop> getAvailableCops() {
		return availableCops;
	}

	public void setAvailableCops(ArrayList<PatrolCop> availableCops) {
		this.availableCops = availableCops;
	}

}// class