
public class wrongIDException extends Exception {

}
