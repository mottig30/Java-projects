
public class wrongRankException extends Exception {

}
