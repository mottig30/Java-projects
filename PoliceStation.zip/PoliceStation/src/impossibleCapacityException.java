
public class impossibleCapacityException extends Exception {

}
