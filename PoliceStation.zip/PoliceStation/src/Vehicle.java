import java.util.ArrayList;

abstract class Vehicle implements Comparable<Vehicle>, Costable {

	//Fields of the class:
	
	protected int carID;
	protected int speed;
	protected double usageCost;
	protected ArrayList<PatrolCop> vehicleWithCops = new ArrayList<PatrolCop>();
	protected int capacity;
	
	//Constructors:

	public Vehicle(int carId, int speed, double usageCost) {// constructor
		this.carID = carId;
		this.speed = speed;
		this.usageCost = usageCost;
	}

	public Vehicle(Vehicle v) {// constructor to return the vehicle to available
		this.carID = v.carID;
		this.speed = v.speed;
		this.usageCost = v.usageCost;
	}
	
	//Methods of the class:
	
	public int compareTo(Vehicle o) { // compare the vehicle by speed
		if (this.speed > o.speed)
			return 1;
		if (this.speed < o.speed)
			return -1;
		return 0;
	}
	
	public void addPatrolCop(PatrolCop pC) throws maxCapacityException {// aggressive reaction if try add after full
		vehicleWithCops.add(pC);
		
	}
	
	public void addOfficer(Officer officer) {
		
	}
	

	
	//Getters:

	public ArrayList<PatrolCop> getVehicleWithCops() {
		return vehicleWithCops;
	}


	public int getCarID() {
		return carID;
	}

	public double getCost() {
		return usageCost;
	}
	
	public int getcapacity() {
		return capacity;
	}


	


}// class
