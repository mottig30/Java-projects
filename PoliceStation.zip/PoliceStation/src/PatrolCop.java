import java.util.ArrayList;

public class PatrolCop implements Comparable<PatrolCop>, Costable, Experienceable {

	//Fields of the class:
	
	public String name;
	public int ID;
	public double experience;
	public int factor;
	public boolean canDrive;
	public int salary = 0;
	public ArrayList<PatrolCop> UnwantedCop;

	// constructors:
	
	public PatrolCop(String name, int ID, double experience, int factor, boolean canDrive) throws wrongIDException {// constructor

        String Str_ID=Integer.toString(ID);//check ID, casting to string
		if (Str_ID.length()!=5) {
			throw new wrongIDException();
		}
		
		this.name = name;
		this.ID = ID;
		this.experience = experience;
		this.canDrive = canDrive;
		UnwantedCop = new ArrayList<PatrolCop>();
	}
	
	public PatrolCop(PatrolCop p) {// constructor to return the patrol cop to available
		
		this.name = p.name;
		this.ID = p.ID;
		this.experience = p.experience;
		this.canDrive = p.canDrive;
		this.UnwantedCop = p.UnwantedCop;
	}
	
	//Methods of the class:
	
	private void UnwantedCop(PatrolCop c) {
		
		if(UnwantedCop.contains(c)==false)//case cop already on the list
			UnwantedCop.add(c);
		else
			System.out.println("Cop already on the list");
	}
	
	public String toString() { // just for checking
		return "name:" + " " + name + ", " + "ID:" + " " + ID;
	}
	
	public int compareTo(PatrolCop other) {// compare the patrol cops by experience
		if (this.experience > other.experience)
			return 1;
		if (this.experience < other.experience)
			return -1;
		return 0;

	}
	
	public void salary(CrimeEvent c) { // update patrol cop salary 
	this.salary += factor * c.getLevel();
}
	
	//Getters:
	
	public String getName() {
		return name;
	}

	public ArrayList<PatrolCop> getUnwantedCop() {
		return UnwantedCop;
	}

	public int getSalary() {
		return salary;
	}

	public double getExperience() {
		return experience;
	}

	public int getID() {
		return ID;
	}

	public double getCost() {
		return salary;
	}



}// class
