
public interface Costable {
	public double getCost();
}
