import java.util.Random;

public class Motorcycle extends Vehicle {

	// Fields of the class:

	private int capacity;// number of cops on the motorcycle

	// Constructors:

	public Motorcycle(int carId, int speed, double usageCost) { // constructor
		super(carId, speed, usageCost);
		int random = randomize();
		if (random == 0)
			this.capacity = 1;
		if (random == 1)
			this.capacity = 2;

	}

	public Motorcycle(Motorcycle Mo) {// constructor to return the motorcycle to available
		super(Mo);
		this.capacity = Mo.getcapacity();

	}

	// Methods of the class:

	public void addPatrolCop(PatrolCop pC) throws maxCapacityException { // add patrol cop to vehicle by checking the place
		boolean copadded = false;
		boolean licens=false;
		if (capacity == 1 && vehicleWithCops.size() == 0 && copadded == false&&pC.canDrive==true) {
			vehicleWithCops.add(pC);
			copadded = true;
		}
		if (capacity == 1 && vehicleWithCops.size() == 1 && copadded == false) {// exception!!!
			throw new maxCapacityException();
		}
		if (capacity == 2 && vehicleWithCops.size() == 0 && copadded == false) {
			vehicleWithCops.add(pC);
			copadded = true;
		}
		if(vehicleWithCops.size()>0) {
		if (capacity == 2 && vehicleWithCops.size() == 1 && copadded == false&&vehicleWithCops.get(0).canDrive==true) {
			vehicleWithCops.add(pC);
			copadded = true;
		}
		if (capacity == 2 && vehicleWithCops.size() == 1 && copadded == false&&vehicleWithCops.get(0).canDrive==false&&pC.canDrive==true) {
			vehicleWithCops.add(pC);
			copadded = true;
		}
		
		}
		
		if (capacity == 2 && vehicleWithCops.size() == 2 && copadded == false) {// exception!!!
			throw new maxCapacityException();
		}
	}

	public int randomize() {// method that return 0 or 1
		Random rand = new Random();
		int x = rand.nextInt(2);// generate 0 or 1 (50%)
		return x;
	}

	public int getcapacity() {
		return capacity;
	}
	
	

}// class
