import java.util.ArrayList;

public class CrimeEvent implements Comparable<CrimeEvent> {
	
	//Fields of the class:

	private int level;
	private String location;
	private ArrayList<Vehicle> vehiclesReadyForEvent; // array list contain all the vehicles full of cops ready for the event
	private boolean validEvent; // check if the event is all ready handled
	private boolean eventClose; // to know if the event close or open
	public int allCopsInEvent;
	
	
	//constructors:

	public CrimeEvent(int level, String location) {// constructor

		this.level = level;
		this.location = location;
		vehiclesReadyForEvent = new ArrayList<Vehicle>();
		validEvent = true;
		allCopsInEvent=0;
	}
	
	//Methods of the class:
	

	public int compareTo(CrimeEvent c) {// compare the crime event by the level
		if (getLevel() > c.getLevel())
			return 1;
		if (getLevel() < c.getLevel())
			return -1;
		return 0;

	}

	public void addVehicle(Vehicle vehicle) {
		vehiclesReadyForEvent.add(vehicle);
	}
	
	public void setallCopsInEvent(int x) {
		if(x>=0)
			this.allCopsInEvent=x;
	
	}

	public String getLocation() {
		return location;
	}

	public ArrayList<Vehicle> getVehiclesReadyForEvent() {
		return vehiclesReadyForEvent;
	}

	public boolean isValidEvent() {
		return validEvent;
	}

	public boolean isEventClose() {
		return eventClose;
	}

	public int getLevel() {
		return level;
	}

	public void setEventClose(boolean eventClose) {
		this.eventClose = eventClose;
	}

	public void setVehiclesReadyForEvent(ArrayList<Vehicle> vehiclesReadyForEvent) {
		this.vehiclesReadyForEvent = vehiclesReadyForEvent;
	}
	
}// class
